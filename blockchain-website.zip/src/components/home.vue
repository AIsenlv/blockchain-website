<style>
@import '../starry_view/style.css';
</style>

<template>
  <div class="com-cention">
    <Header/>
    <section class="com-publicity">
        <div id="particles-js" class="isd"></div>
        <div class="backyuan">
            <div class='backimg'></div>
        </div>
        <div class="logoback"></div>
    </section>
  </div>
</template>

<script>
import Header from './common/header.vue'
import '../starry_view/particles.min.js'
import '../starry_view/app.js'
export default {
  data () {
    return {
        
    }
  },
  components:{
    Header
  },
  created(){
   
  },
  methods:{
      
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less">
  @import '../style/common.less';
  @import '../style/index.less';
  
</style>
